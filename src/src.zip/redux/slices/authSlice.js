import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  token: localStorage.getItem('autorisationToken') || null,
  isAuthenticated: !!localStorage.getItem('autorisationToken'),
  error: null,
}

export const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    login: (state, { payload }) => {
      const { token, user } = payload
      state.token = token
      state.isAuthenticated = true
      state.user = user
      localStorage.setItem('autorisationToken', token)
    },
    logout: (state) => {
      state.token = null
      state.isAuthenticated = false
      state.user = null
      localStorage.removeItem('autorisationToken')
    },
  },
})

export const { login, logout } = authSlice.actions
export default authSlice.reducer
