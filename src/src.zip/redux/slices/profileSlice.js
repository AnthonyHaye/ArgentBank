import { createSlice } from '@reduxjs/toolkit'

const initialeState = {
  user: null,
  loading: false,
  error: null,
}

export const profileSlice = createSlice({
  name: 'profile',
  initialeState,
  reducers: {
    /**
     * Action pour démarrer la récupération ou la mise à jour des informations utilisateur.
     */
    fetchProfilStart: (state) => {
      state.loading = true
      state.error = null
    },
    /**
     * Action pour récupérer les informations de l'utilisateur avec succès.
     */
    fetchProfileSuccess: (state, { payload }) => {
      state.user = payload
      state.loading = false
    },
    /**
     * Action pour gérer les erreurs lors de la récupération/mise à jour des informations utilisateur.
     */
    fetchProfileFailure: (state, { payload }) => {
      state.error = payload
      state.loading = false
    },
  },
})

//exporter les actions pour les utiliser dans les composants
export const { fetchProfileStart, fetchProfileSuccess, fetchProfileFailure } =
  profileSlice.actions

export default profileSlice.reducer
