//Pour authentifier
export const loginUser = async (email, password) => {
  const response = await fetch('http://localhost:3001/api/v1/user/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ email, password }),
  })
  if (!response.ok) {
    const errorData = await response.json()
    throw new Error(errorData.message || 'Echec de la connexion')
  }
  const data = await response.json()
  console.log('Response API pour le Login:', data)

  return data
}

//Récupère les informations du profil utilisateur avec une requête post au serveur

export const getUserProfile = async (token) => {
  if (!token) {
    throw new Error('Token manquant pour la récupération du profil utilisateur')
  }

  const response = await fetch('http://localhost:3001/api/v1/user/profile', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
  })

  if (!response.ok) {
    const errorData = await response.json()
    throw new Error(
      errorData.message || 'Echec de récupération du profil utilisateur',
    )
  }

  return response.json()
}
