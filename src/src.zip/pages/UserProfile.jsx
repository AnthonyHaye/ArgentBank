const Profile = () => <h1>Profil utilisateur</h1>
export default Profile
